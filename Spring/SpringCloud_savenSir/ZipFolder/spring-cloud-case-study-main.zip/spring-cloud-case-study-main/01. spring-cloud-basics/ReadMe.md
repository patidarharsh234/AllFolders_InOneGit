# **Spring Cloud Basics**

A set of microservices represents the basic spring cloud that contains Business Microservices that perform business operations, a Gateway microservice that defines services routes, a Dicovery Server that registers all microservices and discovers them, and a Config Server that contains mutiple configuration of different microservices.

![](https://gitlab.nenosystems.in/cuickdevteam/spring-cloud-case-study/-/wikis/uploads/489e4f447f1152984ee70cd397758cff/api-gateway_v2.png)
___
